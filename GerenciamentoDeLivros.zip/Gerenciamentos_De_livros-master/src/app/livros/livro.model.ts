export interface Livro {
  nome: string,
  autor: string,
  paginas: number
}
